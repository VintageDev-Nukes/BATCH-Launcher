package net.minecraft.src.krapht.gui;

import net.minecraft.src.IInventory;
import net.minecraft.src.Slot;

public class DummySlot extends Slot{
	public DummySlot(IInventory iinventory, int i, int j, int k) {
		super(iinventory, i, j, k);
	}
}