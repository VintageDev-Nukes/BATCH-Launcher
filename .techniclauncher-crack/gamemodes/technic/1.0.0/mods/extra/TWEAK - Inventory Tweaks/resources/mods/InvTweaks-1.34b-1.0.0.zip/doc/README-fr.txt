|===============================================================|
| INVENTORY TWEAKS Mod - Par Jimeo Wan (jimeo.wan at gmail.com) |
| Lisez-moi                                                     |
|===============================================================|

====== [ INSTALLATION ] ======

1. V�rifiez que ModLoader est bien install� (pour le t�l�charger : http://www.minecraftforum.net/topic/75440-risugamis-mods)
2. Supprimez toute ancienne version d'Inventory Tweaks
3. Mettez ce .zip dans le dossier "mods" de Minecraft [OU] Copiez tout le contenu du .zip dans "minecraft.jar"
4. Lancez le jeu ! Un bouton "..." dans votre inventaire donnera acc�s aux options et � l'aide (en anglais).

====== [ LIENS ] ======

* Topic Minecraft Forum (en anglais) : http://www.minecraftforum.net/topic/323444-inventory-tweaks
* Topic Minecraft.fr : minecraft.fr/forum/index.php?threads/14906/
* Site officiel (en anglais) : http://wan.ka.free.fr/?invtweaks
* Code source : https://github.com/jimeowan/inventory-tweaks