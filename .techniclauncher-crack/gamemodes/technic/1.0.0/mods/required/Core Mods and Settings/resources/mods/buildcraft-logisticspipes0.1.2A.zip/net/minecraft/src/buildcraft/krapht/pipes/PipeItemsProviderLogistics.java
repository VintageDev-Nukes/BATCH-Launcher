/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht.pipes;

import java.util.HashMap;

import net.minecraft.src.IInventory;
import net.minecraft.src.ItemStack;
import net.minecraft.src.TileEntity;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.api.Position;
import net.minecraft.src.buildcraft.core.Utils;
import net.minecraft.src.buildcraft.krapht.IProvideItems;
import net.minecraft.src.buildcraft.krapht.IRequestItems;
import net.minecraft.src.buildcraft.krapht.LogisticsOrderManager;
import net.minecraft.src.buildcraft.krapht.LogisticsPromise;
import net.minecraft.src.buildcraft.krapht.LogisticsRequest;
import net.minecraft.src.buildcraft.krapht.LogisticsTransaction;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;
import net.minecraft.src.buildcraft.krapht.Router;
import net.minecraft.src.buildcraft.krapht.logic.LogicProvider;
import net.minecraft.src.buildcraft.transport.TileGenericPipe;
import net.minecraft.src.krapht.InventoryUtil;
import net.minecraft.src.krapht.InventoryUtilFactory;
import net.minecraft.src.krapht.ItemIdentifier;

public class PipeItemsProviderLogistics extends RoutedPipe implements IProvideItems{

	private LogisticsOrderManager _orderManager = new LogisticsOrderManager();
	private InventoryUtilFactory _inventoryUtilFactory = new InventoryUtilFactory();
		
	public PipeItemsProviderLogistics(int itemID) {
		super(new LogicProvider(), itemID);
	}
	
	public PipeItemsProviderLogistics(int itemID, 
										InventoryUtilFactory inventoryUtilFactory,
										LogisticsOrderManager logisticsOrderManager) {
		this(itemID);		
		_inventoryUtilFactory = inventoryUtilFactory;
		_orderManager = logisticsOrderManager;
	}
	

	public int getTotalItemCount(ItemIdentifier item) {
			int count = 0;
			for (Orientations o : Orientations.values()){
				Position p = new Position(xCoord, yCoord, zCoord, o);
				p.moveForwards(1);
				TileEntity tile = worldObj.getBlockTileEntity((int)p.x, (int)p.y, (int)p.z);
				if (!(tile instanceof IInventory)) continue;
				if (tile instanceof TileGenericPipe) continue;
				InventoryUtil inv = _inventoryUtilFactory.getInventoryUtil(Utils.getInventory((IInventory) tile));
				count += inv.itemCount(item);
			}
			return count;
		}

	private int sendItem(ItemIdentifier item, int maxCount, Router destination) {
		int sent = 0;
		for (Orientations o : Orientations.values()){
			Position p = new Position(xCoord, yCoord, zCoord, o);
			p.moveForwards(1);
			TileEntity tile = worldObj.getBlockTileEntity((int)p.x, (int)p.y, (int)p.z);
			if (!(tile instanceof IInventory)) continue;
			if (tile instanceof TileGenericPipe) continue;
			
			InventoryUtil inv = new InventoryUtil(Utils.getInventory((IInventory) tile));
			if (inv.itemCount(item)> 0){
				ItemStack removed = inv.getSingleItem(item);
				super.sendRoutedItem(removed, destination, p);
				sent++;
				maxCount--;
				if (maxCount < 1) break;
			}			
		}
		return sent;
	}

	@Override
	public int getCenterTexture() {
		return mod_LogisticsPipes.LOGISTICSPIPE_PROVIDER_TEXTURE;
	}

	@Override
	public int getAvailableItemCount(ItemIdentifier item) {
		return getTotalItemCount(item) - _orderManager.totalItemsCountInOrders(item); 
	}
	
	@Override
	public void updateEntity() {
		super.updateEntity();
		
		if (!_orderManager.hasOrders() || worldObj.getWorldTime() % 10 != 0) return;
		LogisticsRequest order = _orderManager.getNextRequest();
		int sent = sendItem(order.getItem(), order.numberLeft(), order.getDestination().getRouter());
		if (sent > 0){
			_orderManager.sendSuccessfull(sent);
		}
		else {
			_orderManager.sendFailed();
		}
	}

	@Override
	public void canProvide(LogisticsTransaction transaction) {
		// Check the transaction and see if we have helped already
		HashMap<ItemIdentifier, Integer> commited = transaction.getTotalPromised(this);
		for (LogisticsRequest request : transaction.getRemainingRequests()){
			int canProvide = getAvailableItemCount(request.getItem());
			if (commited.containsKey(request.getItem())){
				canProvide -= commited.get(request.getItem());
			}
			if (canProvide < 1) continue;
			LogisticsPromise promise = new LogisticsPromise();
			promise.item = request.getItem();
			promise.numberOfItems = Math.min(canProvide, request.notYetAllocated());
			promise.sender = this;
			request.addPromise(promise);
			commited = transaction.getTotalPromised(this);
		}
	}
	
	@Override
	public void fullFill(LogisticsPromise promise, IRequestItems destination) {
		_orderManager.addOrder(new LogisticsRequest(promise.item, promise.numberOfItems, destination));
	}

	@Override
	public Router getRouter() {
		return router;
	}
}
