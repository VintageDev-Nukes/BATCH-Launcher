package net.minecraft.src.buildcraft.krapht;

import net.minecraft.src.Item;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.forge.ITextureProvider;

public class LogisticsItem extends Item implements ITextureProvider{

	public LogisticsItem(int i) {
		super(i);
	}
	
	@Override
	public String getTextureFile() {
		return mod_LogisticsPipes.LOGISTICSITEMS_TEXTURE_FILE;
	}

}
