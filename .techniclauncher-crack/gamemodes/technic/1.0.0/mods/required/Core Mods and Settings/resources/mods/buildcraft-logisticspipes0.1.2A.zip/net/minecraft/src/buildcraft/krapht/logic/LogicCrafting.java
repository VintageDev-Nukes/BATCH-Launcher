/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht.logic;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.ItemStack;
import net.minecraft.src.ModLoader;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.NBTTagList;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.krapht.GuiCraftingPipe2;
import net.minecraft.src.buildcraft.krapht.IRequestItems;
import net.minecraft.src.buildcraft.krapht.IRequireReliableTransport;
import net.minecraft.src.buildcraft.krapht.LogisticsManager;
import net.minecraft.src.buildcraft.krapht.LogisticsRequest;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;
import net.minecraft.src.buildcraft.krapht.Router;
import net.minecraft.src.buildcraft.transport.TileGenericPipe;
import net.minecraft.src.krapht.ItemIdentifier;

public class LogicCrafting extends BaseRoutingLogic implements IRequireReliableTransport{

	ItemStack [] items = new ItemStack [10];
	
	private final LinkedList<ItemIdentifier> _lostItems = new LinkedList<ItemIdentifier>(); 
	
	public int SatelliteId = 0;
	
	public LogicCrafting() {
		throttleTime = 40;
	}
	
	/** SATELLITE CODE **/
	
	private int getNextConnectSatelliteId(boolean prev){
		HashMap<Router, Orientations> routes = getRouter().getRouteTable();
		int closestIdFound = prev?0:Integer.MAX_VALUE;
		for (LogicSatellite satellite : LogicSatellite.AllSatellites){
			if (routes.containsKey(satellite.getRouter())){
				if (!prev && satellite.satelliteId > SatelliteId && satellite.satelliteId < closestIdFound) {
					closestIdFound = satellite.satelliteId;
				} else if (prev && satellite.satelliteId < SatelliteId && satellite.satelliteId > closestIdFound){
					closestIdFound = satellite.satelliteId;
				}
			}
		}
		if (closestIdFound == Integer.MAX_VALUE)
			return SatelliteId;
		
		return closestIdFound;
		
	}
	
	public void setNextSatellite(){
		SatelliteId = getNextConnectSatelliteId(false);
	}
	
	public void setPrevSatellite(){
		SatelliteId = getNextConnectSatelliteId(true);
	}
	
	public boolean isSatelliteConnected(){
		for (LogicSatellite satellite : LogicSatellite.AllSatellites){
			if (satellite.satelliteId == SatelliteId){
				if (this.getRouter().getRouteTable().containsKey(satellite.getRouter())){
					return true;
				}
			}
		}
		return false;
	}
	
	public Router getSatelliteRouter(){
		for (LogicSatellite satellite : LogicSatellite.AllSatellites){
			if (satellite.satelliteId == SatelliteId){
				return satellite.getRouter();
			}
		}
		return null;
	}
	
	public void paintPathToSatellite() {
		Router satelliteRouter = getSatelliteRouter();
		if (satelliteRouter == null) return;
		
		this.getRouter().displayRouteTo(satelliteRouter);
		
	}
	
	
	/** OTHER CODE **/
	
	public int RequestsItem(ItemIdentifier item) {
		if (item == null){
			return 0;
		}
		int total = 0;
		for(ItemStack is : items) {
			if (is == null) continue;
			if (item == ItemIdentifier.get(is)) {
				total += is.stackSize;
			}
		}
		return total;
	}
	

	@Override
	public int getSizeInventory() {
		return items.length;
	}
	
	@Override
	public ItemStack getStackInSlot(int i) {
		return items [i];
	}

	@Override
	public ItemStack decrStackSize(int i, int j) {		
		ItemStack stack = items [i].copy();
		stack.stackSize = j;
		
		items [i].stackSize -= j;
		
		if (items [i].stackSize == 0) {
			items [i] = null;
		}
		return stack;
	}

	@Override
	public void setInventorySlotContents(int i, ItemStack itemstack) {
		items [i] = itemstack;
	}
	
	@Override
	public String getInvName() {		
		return "Requested items";
	}

	@Override
	public int getInventoryStackLimit() {
		return 64;
	}

	@Override
	public boolean canInteractWith(EntityPlayer entityplayer) {
		// TODO Auto-generated method stub
		return true;
	}
	
	public void readFromNBT(NBTTagCompound nbttagcompound) {
		super.readFromNBT(nbttagcompound);	
		
		NBTTagList nbttaglist = nbttagcompound.getTagList("items");
    	
    	for (int j = 0; j < nbttaglist.tagCount(); ++j) {    		
    		NBTTagCompound nbttagcompound2 = (NBTTagCompound) nbttaglist.tagAt(j);
    		int index = nbttagcompound2.getInteger("index");
    		items [index] = ItemStack.loadItemStackFromNBT(nbttagcompound2);
    	}
    	SatelliteId = nbttagcompound.getInteger("satelliteid");
    }

    public void writeToNBT(NBTTagCompound nbttagcompound) {
    	super.writeToNBT(nbttagcompound);
    	
		NBTTagList nbttaglist = new NBTTagList();
    	
    	for (int j = 0; j < items.length; ++j) {    		    		
    		if (items [j] != null && items [j].stackSize > 0) {
        		NBTTagCompound nbttagcompound2 = new NBTTagCompound ();
        		nbttaglist.setTag(nbttagcompound2);
    			nbttagcompound2.setInteger("index", j);
    			items [j].writeToNBT(nbttagcompound2);	
    		}     		
    	}
    	
    	nbttagcompound.setTag("items", nbttaglist);
    	nbttagcompound.setInteger("satelliteid", SatelliteId);
    }
	
	@Override
	public boolean addItem(ItemStack stack, boolean doAdd, Orientations from) {
		return false;
	}

	@Override
	public ItemStack extractItem(boolean doRemove, Orientations from) {
		return null;
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onWrenchClicked(EntityPlayer entityplayer) {
		ModLoader.getMinecraftInstance().displayGuiScreen(new GuiCraftingPipe2(entityplayer.inventory, this.container, this));
	}

	
	@Override
	public void throttledUpdateEntity() {
		super.throttledUpdateEntity();
		if (_lostItems.isEmpty()) return;
		System.out.println("Item lost");
		Iterator<ItemIdentifier> iterator = _lostItems.iterator();
		while(iterator.hasNext()){
			LogisticsRequest request = new LogisticsRequest(iterator.next(), 1, (IRequestItems)this.getRoutedPipe());
			if (LogisticsManager.Request(request, ((RoutedPipe)((TileGenericPipe)this.container).pipe).router.getRouteTable().keySet(), null)){
				iterator.remove();
			}
		}
	}
	
	@Override
	public void itemArrived(ItemIdentifier item) {}

	@Override
	public void itemLost(ItemIdentifier item) {
		_lostItems.add(item);
	}

	
	
}
