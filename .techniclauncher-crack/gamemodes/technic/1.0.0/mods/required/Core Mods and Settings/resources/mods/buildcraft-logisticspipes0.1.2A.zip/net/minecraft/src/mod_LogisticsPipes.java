/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */
/*
 
 
Manual testing:
 * Recipe
 * Logistics manager
 * Routing
 * 
Testing help
 * Logistics manager
 * Routing
 
ChangeLog:

 - 0.1.2
	TODO: 
		* REMOVE DEBUG CODE (always! ALL OF IT!)
		
	New stuff:
		* Added Supplier pipe. Will try to keep an inventory supplied with the configured materials by requesting them from the network. Checks every 5 seconds 
			(Do not place a provider pipe on the same chest and same network. It will not work!)
		* Added network monitor. Using this on any logistic pipe will bring up some network statistics
		* Testing different a type of interface for supplier pipe. You do not need to use real items to configure suppliers.
		* Requester pipes and crafting pipes will now attempt to re-request any items that go missing
		* Added a network monitor to track some stats on the pipes.,
		* 
		* Some behind the scenes tech improvements to be closer to saving the routed items to the world file.

	Bug fixes:
		* Changed the route table calculations to lazy-load (on demand). Didn't see a point to completely 
			recalculate the route table for every single router whenever the network changed. This should hopefully remove 
			the massive lag spike some players are experiencing on maps with many pipes.
		* Fixed provider pipes so they now work with double chests.	
		* Fixed the speed that non-requested extras from crafting pipes are extracted at.
		* Fixed routing for items tagged with a destination that cannot be reached. It will now attempt to route it somewhere else or drop it. 
			This is to prevent items randomly flowing around the logistics network.
	
	Other:
		* Items going to satellite pipes are now directly routed there
		* Items crafted in furnace (or anything except crafting table) will now be picked up as soon as it is ready.
		* Obsidian pipes will now (in addition to iron pipes) separate two networks 
		* Routing is now much more strict. Items in logistics pipes will no longer sometimes default to buildcraft's standard way of directing items. 
			If a pipe can not find a valid destination it will be dropped.

  	Remaining Issues:
		* Its possible to cause circular recursion by have a crafting pipe craft A using B, at the same time as having another crafting pipe crafting B using A. This will crash the game
		* Multiple providers on same chest.
		* Supplier and provider connected to same chest and network.
		* 


 - 0.1.1
	New stuff:
		* Added support in the crafting pipe to most IInventories (furnaces, chests etc)
		* Added an output message stating why a request failed. Easier to know what you ran out of, easier for me to debug.
		* Added new pipe, satellite pipe, these can be connected to crafting pipes and, if enabled, will send incoming materials in the 3 rightmost slots to the satellite instead of through the crafting pipe.
		* 
 		
 	Bug fixes:
 		* Renamed zip file to solve issues on *nix (including Mac) when logisticspipes was loaded before buildcraft
 		* Renamed zip file to solve texture issues with other mods, only appearing when the other mod loaded after buildcraft, but before logisticspipes
 		* Did the right thing and added initiation of buildcraft, just in case this mod loads before buildcraft core.
 		* Fixed recipe for crafting pipe now its "dPd", d = Diamond, P =Basic Logistics Pipe 
 		* Routing no longer assumes that pipes next to each other actually are connected. (Cobblestone, smoothstone)
 		* Routing also makes additional checks to ensure that we don't try and route over waterproof or conductive pipes.
 		* Route painting has been moved to the same method that calculates the paths for routes making it more robust and accurate
 		* Remove debug code accidently left in provider pipes (to set time to day)
 		* Fixed bug where provider pipes extracts from connected pipes with inventory.
 		* Logisticsmanager will now properly make use of extra resources produced within a request
 		* Logisticsmanager will now make use of any extras from previous request that have not been crafted yet.
 		* Redid some routing logic. All routers now share a single map of all routers instead of having its own. Let me know how this works out
 		* Rightclicking on all all logisticspipes (except provider) will now allow placing of pipes
 		
 	Other:
 		* Redesigned craftingpipe gui
 		* Changed the default routed speed to 10x normal speed, up from 5x. Upgrading users will have to update their config file.
 		
 - 0.1.0
 - Alternate texture for routed exits
 - Performance related fix that caused recalculation of shortest even when paths had not changed.
 - Fixed bug that was could cause items to slow down if it was inputed at speeds higher than the speed the router would send them.
 - "Fixed" routing bug - network wasn't converging when loading world
 - Iron pipes separate network segments
 - Crafting, need specify input->output for logistics in gui (dynamic recepies)
 - Logs to modloader.txt which texture ids it gets from buildcraft

 
 
TODO later, maybe....
 - Status screen (in transit, waiting for craft, ready etc)
 - RoutedEntityItem, targetTile - specify which "chest" it should be delivered to
 - RoutedEntityItem, travel time
 - Change recipes to chip-sets in 3.0.0.0
 - Add in-game item for network management (turn on/off link detection, poke link detection etc) ?
 - Context sensitive textures. Flashing routers on deliveries?
 - Track deliveries / en route ?
 - Save stuff, like destinations
 - Texture improvement
 - Route liquids (in container)?
 - Persistance:
 	- Save logistics to file. Save coordinates so they can be resolved later. Also save items in transit and count them as not delivered
 - SMP:
	- Peering, transport other peoples items. Need hook to set owner of PassiveEntity
 */

package net.minecraft.src;

import java.io.File;

import net.minecraft.src.buildcraft.core.CoreProxy;
import net.minecraft.src.buildcraft.krapht.ILogisticsManager;
import net.minecraft.src.buildcraft.krapht.LogisticsItem;
import net.minecraft.src.buildcraft.krapht.LogisticsManager;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsBasicLogistics;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsCraftingLogistics;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsProviderLogistics;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsRequestLogistics;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsSatelliteLogistics;
import net.minecraft.src.buildcraft.krapht.pipes.PipeItemsSupplierLogistics;
import net.minecraft.src.buildcraft.transport.BlockGenericPipe;
import net.minecraft.src.buildcraft.transport.Pipe;
import net.minecraft.src.forge.Configuration;
import net.minecraft.src.forge.MinecraftForgeClient;
import net.minecraft.src.forge.Property;

public class mod_LogisticsPipes extends BaseMod{
	
	public static boolean DEBUG = false;
	
	//Items
	public static Item LogisticsBasicPipe;
	public static Item LogisticsRequestPipe;
	public static Item LogisticsProviderPipe;
	public static Item LogisticsCraftingPipe;
	public static Item LogisticsSatellitePipe;
	public static Item LogisticsSupplierPipe;
	
	public static Item LogisticsNetworkMonitior;
	
	
	//Ids
	
	public static int LOGISTICSNETWORKMONITOR_ID					= 6873;
	
	public static int LOGISTICSPIPE_BASIC_ID						= 6874;
	public static int LOGISTICSPIPE_REQUEST_ID						= 6875;
	public static int LOGISTICSPIPE_PROVIDER_ID						= 6876;
	public static int LOGISTICSPIPE_CRAFTING_ID						= 6877;
	public static int LOGISTICSPIPE_SATELLITE_ID					= 6878;
	public static int LOGISTICSPIPE_SUPPLIER_ID						= 6879;
	
	//Texture #
	
	public static final int LOGISTICSNETWORKMONITOR_ICONINDEX = 0 * 16 + 0;
	
	public static int LOGISTICSPIPE_TEXTURE					= 0;
	public static int LOGISTICSPIPE_PROVIDER_TEXTURE		= 0;
	public static int LOGISTICSPIPE_REQUESTER_TEXTURE		= 0;
	public static int LOGISTICSPIPE_CRAFTER_TEXTURE			= 0;
	public static int LOGISTICSPIPE_SATELLITE_TEXTURE		= 0;
	public static int LOGISTICSPIPE_SUPPLIER_TEXTURE		= 0;
	public static int LOGISTICSPIPE_ROUTED_TEXTURE			= 0;
	public static int LOGISTICSPIPE_NOTROUTED_TEXTURE		= 0;
	
	//Texture files
	
	public static final String LOGISTICSITEMS_TEXTURE_FILE = "/net/minecraft/src/buildcraft/krapht/gui/item_textures.png";
	
	public static final String LOGISTICSPIPE_TEXTURE_FILE			= "/net/minecraft/src/buildcraft/krapht/gui/logisticspipe.png";
	public static final String LOGISTICSPIPE_PROVIDER_TEXTURE_FILE	= "/net/minecraft/src/buildcraft/krapht/gui/logisticspipeprovider.png";
	public static final String LOGISTICSPIPE_REQUESTER_TEXTURE_FILE	= "/net/minecraft/src/buildcraft/krapht/gui/logisticspiperequester.png";
	public static final String LOGISTICSPIPE_CRAFTER_TEXTURE_FILE	= "/net/minecraft/src/buildcraft/krapht/gui/logisticspipecrafter.png";
	public static final String LOGISTICSPIPE_SATELLITE_TEXTURE_FILE	= "/net/minecraft/src/buildcraft/krapht/gui/logisticspipesatellite.png";
	public static final String LOGISTICSPIPE_SUPPLIER_TEXTURE_FILE	= "/net/minecraft/src/buildcraft/krapht/gui/logisticspipesupplier.png";
	public static final String LOGISTICSPIPE_ROUTED_TEXTURE_FILE	= "/net/minecraft/src/buildcraft/krapht/gui/logisticspiperouted.png";
	public static final String LOGISTICSPIPE_NOTROUTED_TEXTURE_FILE	= "/net/minecraft/src/buildcraft/krapht/gui/logisticspipenotrouted.png";
	
	//Configrables
	public static int LOGISTICS_DETECTION_LENGTH	= 50;
	public static int LOGISTICS_DETECTION_COUNT		= 100;
	public static int LOGISTICS_DETECTION_FREQUENCY = 20;
	
	public static final float LOGISTICS_ROUTED_SPEED_MULTIPLIER	= 20F;
	public static final float LOGISTICS_DEFAULTROUTED_SPEED_MULTIPLIER = 10F;
	
	private static Configuration configuration;
	
	/** stuff for testing **/
	
	public static ILogisticsManager logisticsManager = new LogisticsManager();
	
	@Override
	public void ModsLoaded() {
		super.ModsLoaded();
		
		BuildCraftCore.initialize();
		
		File configFile = new File(CoreProxy.getBuildCraftBase(), "config/LogisticsPipes.cfg");
		configuration = new Configuration(configFile);
		configuration.load();
		
		Property logisticNetworkMonitorIdProperty = configuration.getOrCreateIntProperty("logisticsNetworkMonitor.id", Configuration.ITEM_PROPERTY, LOGISTICSNETWORKMONITOR_ID);
		logisticNetworkMonitorIdProperty.comment = "The item id for the basic logistics pipe";
		
		Property logisticPipeIdProperty = configuration.getOrCreateIntProperty("logisticsPipe.id", Configuration.ITEM_PROPERTY, LOGISTICSPIPE_BASIC_ID);
		logisticPipeIdProperty.comment = "The item id for the basic logistics pipe";
		
		Property logisticPipeRequesterIdProperty = configuration.getOrCreateIntProperty("logisticsPipeRequester.id", Configuration.ITEM_PROPERTY, LOGISTICSPIPE_REQUEST_ID);
		logisticPipeRequesterIdProperty.comment = "The item id for the requesting logistics pipe";
		
		Property logisticPipeProviderIdProperty = configuration.getOrCreateIntProperty("logisticsPipeProvider.id", Configuration.ITEM_PROPERTY, LOGISTICSPIPE_PROVIDER_ID);
		logisticPipeProviderIdProperty.comment = "The item id for the providing logistics pipe";
		
		Property logisticPipeCraftingIdProperty = configuration.getOrCreateIntProperty("logisticsPipeCrafting.id", Configuration.ITEM_PROPERTY, LOGISTICSPIPE_CRAFTING_ID);
		logisticPipeCraftingIdProperty.comment = "The item id for the crafting logistics pipe";

		Property logisticPipeSatelliteIdProperty = configuration.getOrCreateIntProperty("logisticsPipeSatellite.id", Configuration.ITEM_PROPERTY, LOGISTICSPIPE_SATELLITE_ID);
		logisticPipeSatelliteIdProperty.comment = "The item id for the crafting satellite pipe";
		
		Property logisticPipeSupplierIdProperty = configuration.getOrCreateIntProperty("logisticsPipeSupplier.id", Configuration.ITEM_PROPERTY, LOGISTICSPIPE_SUPPLIER_ID);
		logisticPipeSupplierIdProperty.comment = "The item id for the supplier pipe";

		
		Property detectionLength = configuration.getOrCreateIntProperty("detectionLength", Configuration.GENERAL_PROPERTY, LOGISTICS_DETECTION_LENGTH);
		detectionLength.comment = "The maximum shortest length between logistics pipes. This is an indicator on the maxim depth of the recursion algorithm to discover logistics neighbours. A low value might use less CPU, a high value will allow longer pipe sections";
		
		Property detectionCount = configuration.getOrCreateIntProperty("detectionCount", Configuration.GENERAL_PROPERTY, LOGISTICS_DETECTION_COUNT);
		detectionCount.comment = "The maximum number of buildcraft pipees (including forks) between logistics pipes. This is an indicator of the maximum ammount of nodes the recursion algorithm will visit before giving up. As it is possible to fork a pipe connection using standard BC pipes the algorithm will attempt to discover all available destinations through that pipe. Do note that the logistics system will not interfere with the operation of non-logistics pipes. So a forked pipe will usually be sup-optimal, but it is possible. A low value might reduce CPU usage, a high value will be able to handle more complex pipe setups. If you never fork your connection between the logistics pipes this has the same meaning as detectionLength and the lower of the two will be used";
		
		Property detectionFrequency = configuration.getOrCreateIntProperty("detectionFrequency", Configuration.GENERAL_PROPERTY, LOGISTICS_DETECTION_FREQUENCY);
		detectionFrequency.comment = "The amount of time that passes between checks to see if it is still connected to its neighbours. A low value will mean that it will detect changes faster but use more CPU. A high value means detection takes longer, but CPU consumption is reduced. A value of 20 will check about every second";
				
		configuration.save();
		 
		LOGISTICSPIPE_BASIC_ID 			= Integer.parseInt(logisticPipeIdProperty.value);
		LOGISTICSPIPE_REQUEST_ID		= Integer.parseInt(logisticPipeRequesterIdProperty.value);
		LOGISTICSPIPE_PROVIDER_ID		= Integer.parseInt(logisticPipeProviderIdProperty.value);
		LOGISTICSPIPE_CRAFTING_ID		= Integer.parseInt(logisticPipeCraftingIdProperty.value);
		LOGISTICSPIPE_SATELLITE_ID		= Integer.parseInt(logisticPipeSatelliteIdProperty.value);
		LOGISTICSPIPE_SUPPLIER_ID		= Integer.parseInt(logisticPipeSupplierIdProperty.value);
		LOGISTICS_DETECTION_LENGTH		= Integer.parseInt(detectionLength.value);
		LOGISTICS_DETECTION_COUNT		= Integer.parseInt(detectionCount.value);
		LOGISTICS_DETECTION_FREQUENCY 	= Math.max(Integer.parseInt(detectionFrequency.value), 1);
		
		LogisticsNetworkMonitior = new LogisticsItem(LOGISTICSNETWORKMONITOR_ID);
		LogisticsNetworkMonitior.setIconIndex(LOGISTICSNETWORKMONITOR_ICONINDEX);
		LogisticsNetworkMonitior.setItemName("networkMonitorItem");

		LOGISTICSPIPE_TEXTURE 			= CoreProxy.addCustomTexture(LOGISTICSPIPE_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_TEXTURE + " for base texture");
		LOGISTICSPIPE_PROVIDER_TEXTURE 	= CoreProxy.addCustomTexture(LOGISTICSPIPE_PROVIDER_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_PROVIDER_TEXTURE + " for provider texture");
		LOGISTICSPIPE_REQUESTER_TEXTURE = CoreProxy.addCustomTexture(LOGISTICSPIPE_REQUESTER_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_REQUESTER_TEXTURE + " for requester texture");
		LOGISTICSPIPE_CRAFTER_TEXTURE	= CoreProxy.addCustomTexture(LOGISTICSPIPE_CRAFTER_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_CRAFTER_TEXTURE + " for crafter texture");
		LOGISTICSPIPE_ROUTED_TEXTURE 	= CoreProxy.addCustomTexture(LOGISTICSPIPE_ROUTED_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_ROUTED_TEXTURE + " for routed texture");
		LOGISTICSPIPE_NOTROUTED_TEXTURE = CoreProxy.addCustomTexture(LOGISTICSPIPE_NOTROUTED_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_NOTROUTED_TEXTURE + " for non-routed texture");
		LOGISTICSPIPE_SATELLITE_TEXTURE = CoreProxy.addCustomTexture(LOGISTICSPIPE_SATELLITE_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_SATELLITE_TEXTURE + " for satellite texture");
		LOGISTICSPIPE_SUPPLIER_TEXTURE = CoreProxy.addCustomTexture(LOGISTICSPIPE_SUPPLIER_TEXTURE_FILE);
		ModLoader.getLogger().fine("LogisticsPipes: got texture id " + LOGISTICSPIPE_SATELLITE_TEXTURE + " for supplier texture");
		
		MinecraftForgeClient.preloadTexture(LOGISTICSITEMS_TEXTURE_FILE);
		
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_TEXTURE_FILE);
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_PROVIDER_TEXTURE_FILE);
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_REQUESTER_TEXTURE_FILE);
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_CRAFTER_TEXTURE_FILE);
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_SATELLITE_TEXTURE_FILE);
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_SUPPLIER_TEXTURE_FILE);
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_ROUTED_TEXTURE_FILE);
		MinecraftForgeClient.preloadTexture(LOGISTICSPIPE_NOTROUTED_TEXTURE_FILE);
		
		
		LogisticsBasicPipe = createPipe(LOGISTICSPIPE_BASIC_ID, PipeItemsBasicLogistics.class, "Basic Logistics Pipe");
		LogisticsRequestPipe = createPipe(LOGISTICSPIPE_REQUEST_ID, PipeItemsRequestLogistics.class, "Request Logistics Pipe");
		LogisticsProviderPipe = createPipe(LOGISTICSPIPE_PROVIDER_ID, PipeItemsProviderLogistics.class, "Provider Logistics Pipe");
		LogisticsCraftingPipe = createPipe(LOGISTICSPIPE_CRAFTING_ID, PipeItemsCraftingLogistics.class, "Crafting Logistics Pipe");
		LogisticsSatellitePipe = createPipe(LOGISTICSPIPE_SATELLITE_ID, PipeItemsSatelliteLogistics.class, "Satellite Logistics Pipe");
		LogisticsSupplierPipe = createPipe(LOGISTICSPIPE_SUPPLIER_ID, PipeItemsSupplierLogistics.class, "Supplier Logistics Pipe");
		
		ModLoader.AddName(LogisticsNetworkMonitior, "Network monitor");
		
		CraftingManager craftingmanager = CraftingManager.getInstance();
		craftingmanager.addRecipe(new ItemStack(LogisticsBasicPipe, 8), new Object[] { "grg", "GdG", "grg", Character.valueOf('g'), Block.glass, 
																									   Character.valueOf('G'), BuildCraftCore.goldGearItem,
																									   Character.valueOf('d'), BuildCraftTransport.pipeItemsDiamond, 
																									   Character.valueOf('r'), Block.torchRedstoneActive});
		
		craftingmanager.addRecipe(new ItemStack(LogisticsRequestPipe, 1), new Object[] { "P", "d", Character.valueOf('P'), mod_LogisticsPipes.LogisticsBasicPipe, Character.valueOf('d'), Item.diamond}); 
		craftingmanager.addRecipe(new ItemStack(LogisticsProviderPipe, 1), new Object[] { "d", "P", Character.valueOf('P'), mod_LogisticsPipes.LogisticsBasicPipe, Character.valueOf('d'), Item.diamond});
		craftingmanager.addRecipe(new ItemStack(LogisticsCraftingPipe, 1), new Object[] { "dPd", Character.valueOf('P'), mod_LogisticsPipes.LogisticsBasicPipe, Character.valueOf('d'), Item.diamond});
		craftingmanager.addRecipe(new ItemStack(LogisticsSatellitePipe, 1), new Object[] { "rPr", Character.valueOf('P'), mod_LogisticsPipes.LogisticsBasicPipe, Character.valueOf('r'), Item.redstone});
		craftingmanager.addRecipe(new ItemStack(LogisticsSupplierPipe, 1), new Object[] { "lPl", Character.valueOf('P'), mod_LogisticsPipes.LogisticsBasicPipe, Character.valueOf('l'), new ItemStack(Item.dyePowder, 1, 4)});
		
		craftingmanager.addRecipe(new ItemStack(LogisticsNetworkMonitior, 1), new Object[] { "g g", " G ", " g ", Character.valueOf('g'), Item.ingotGold, Character.valueOf('G'), BuildCraftCore.goldGearItem});
		
		
		if (mod_LogisticsPipes.DEBUG) {
			
			craftingmanager.addRecipe(new ItemStack(LogisticsNetworkMonitior, 1), new Object[] { "d d", " d ", Character.valueOf('d'), Block.dirt});
			craftingmanager.addRecipe(new ItemStack(LogisticsBasicPipe, 64), new Object[] { "wd", Character.valueOf('w'), Block.wood, Character.valueOf('d'), Block.dirt}); 
			craftingmanager.addRecipe(new ItemStack(LogisticsRequestPipe, 64), new Object[] {"ww", Character.valueOf('w'), Block.wood});
			craftingmanager.addRecipe(new ItemStack(LogisticsProviderPipe, 64), new Object[] {"dd", Character.valueOf('d'), Block.dirt});
			craftingmanager.addRecipe(new ItemStack(LogisticsCraftingPipe, 64), new Object[] {"ddd", Character.valueOf('d'), Block.dirt});
			craftingmanager.addRecipe(new ItemStack(LogisticsSatellitePipe, 64), new Object[] {"d","d", Character.valueOf('d'), Block.dirt});
			craftingmanager.addRecipe(new ItemStack(LogisticsSupplierPipe, 64), new Object[] { "d", "d", "d", Character.valueOf('d'), Block.dirt});
		}
	}
	
	@Override
	public String getVersion() {
		return "0.1.2 (for Minecraft 1.0.0, Buildcraft 2.2.8, Forge 1.2.2)";
	}
	
	private static Item createPipe (int defaultID, Class <? extends Pipe> clas, String descr) {
		String name = Character.toLowerCase(clas.getSimpleName().charAt(0))
				+ clas.getSimpleName().substring(1);
		
		Item res =  BlockGenericPipe.registerPipe (defaultID, clas);
		res.setItemName(clas.getSimpleName());
		CoreProxy.addName(res, descr);
		MinecraftForgeClient.registerCustomItemRenderer(res.shiftedIndex, mod_BuildCraftTransport.instance);
	
		return res;
	}

	@Override
	public void load() {
		// TODO Auto-generated method stub
	}
}
