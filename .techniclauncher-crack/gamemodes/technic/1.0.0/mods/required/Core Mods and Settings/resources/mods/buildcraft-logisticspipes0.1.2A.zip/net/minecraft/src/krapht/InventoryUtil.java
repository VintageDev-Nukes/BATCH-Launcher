package net.minecraft.src.krapht;

import java.util.HashMap;
import java.util.LinkedList;

import net.minecraft.src.IInventory;
import net.minecraft.src.ItemStack;

public class InventoryUtil {
	
	private final IInventory _inventory;
	
	public InventoryUtil(IInventory inventory) {
		_inventory = inventory;
	}
	
	public int itemCount(final ItemIdentifier item){
		int count = 0;
		for (int i = 0; i < _inventory.getSizeInventory(); i++){
			ItemStack stack = _inventory.getStackInSlot(i);
			if (stack == null) continue;
			if (ItemIdentifier.get(stack) == item) {
				count += stack.stackSize;
			}
		}
		return count;
	}
	
	public HashMap<ItemIdentifier, Integer> getItemsAndCount(){
		HashMap<ItemIdentifier, Integer> items = new HashMap<ItemIdentifier, Integer>();
		for (int i = 0; i < _inventory.getSizeInventory(); i++){
			ItemStack stack = _inventory.getStackInSlot(i);
			if (stack == null) continue;
			ItemIdentifier itemId = ItemIdentifier.get(stack);
			if (!items.containsKey(itemId)){
				items.put(itemId, stack.stackSize);
			} else {
				items.put(itemId, items.get(itemId) + stack.stackSize);
			}
		}	
		return items;
	}
	
	public ItemStack getSingleItem(ItemIdentifier item){
		for (int i = 0; i < _inventory.getSizeInventory(); i++){
			ItemStack stack = _inventory.getStackInSlot(i);
			if (stack == null) continue;
			if (ItemIdentifier.get(stack) == item) {
				ItemStack removed = stack.splitStack(1);
				if (stack.stackSize == 0){
					_inventory.setInventorySlotContents(i,  null);
				}
				return removed;
			}
		}
		return null;
	}
	
	public ItemStack getMultipleItems(ItemIdentifier item, int count){
		if (itemCount(item) < count) return null;
		ItemStack stack = null;
		for (int i = 0; i < count; i++){
			if(stack == null){
				stack = getSingleItem(item);
			}
			else{
				stack.stackSize += getSingleItem(item).stackSize;
			}
		}
		return stack;
	}
	

}
