package net.minecraft.src.buildcraft.krapht.logic;

import net.minecraft.src.Block;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ModLoader;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.krapht.GuiRoutingStats;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;
import net.minecraft.src.buildcraft.krapht.Router;
import net.minecraft.src.buildcraft.transport.PipeLogic;
import net.minecraft.src.ItemStack;

public abstract class BaseRoutingLogic extends PipeLogic{
	
	public RoutedPipe getRoutedPipe(){
		return (RoutedPipe) this.container.pipe;
	}
	
	public Router getRouter(){
		return getRoutedPipe().router;
	}
	
	public abstract void onWrenchClicked(EntityPlayer entityplayer);
	
	public abstract void destroy();
	
	protected int throttleTime = 40;
	private int throttleTimeLeft = 0;
	
	
	@Override
	public void updateEntity() {
		// TODO Auto-generated method stub
		super.updateEntity();
		if (--throttleTimeLeft > 0) return;
		throttledUpdateEntity();
		resetThrottle();
	}
	
	public void throttledUpdateEntity(){}
	
	protected void resetThrottle(){
		throttleTimeLeft = throttleTime;
	}
	
	@Override
	public boolean blockActivated(EntityPlayer entityplayer) {
		if (entityplayer.getCurrentEquippedItem() == null)	{
			getRouter().displayRoutes();
			if (mod_LogisticsPipes.DEBUG) {
				doDebugStuff(entityplayer);
			}
			return true;
		} else if (entityplayer.getCurrentEquippedItem().getItem() == mod_LogisticsPipes.LogisticsNetworkMonitior){
			System.out.println("OH YEAH");
			ModLoader.getMinecraftInstance().displayGuiScreen(new GuiRoutingStats(getRouter()));
			return true;
		} else if (entityplayer.getCurrentEquippedItem().getItem() == net.minecraft.src.BuildCraftCore.wrenchItem){
			onWrenchClicked(entityplayer);
			return true;
		}
		return super.blockActivated(entityplayer);
	}
	
	@Override
	public boolean canInteractWith(EntityPlayer entityplayer) {
		// TODO Auto-generated method stub
		return true;
	}

	private void doDebugStuff(EntityPlayer entityplayer){
		entityplayer.worldObj.setWorldTime(4951);
		System.out.println("***");
		Router r = getRouter();
		
		System.out.println("ID: " + r.getId());
		System.out.println("---------CONNECTED TO---------------");
		for (RoutedPipe adj : r._adjacent.keySet())
		{
			System.out.println(adj.router.getId());
		}
		System.out.println("*******ROUTE TABLE**************");
		for (Router p : r.getRouteTable().keySet())
		{
			System.out.println(p.getId() + " -> " + r.getRouteTable().get(p).toString());
		}
		
		System.out.println();
		System.out.println();
//			//Give stuff! for debug purpose, ensure commented before release
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftFactory.autoWorkbenchBlock, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.chest, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftCore.woodenGearItem, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.wood, 64));				
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.brick, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.dirt, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.cobblestone, 64));		
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Item.pickaxeDiamond, 1));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Item.shovelDiamond, 1));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.cobblestone, 64));						
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.torchRedstoneActive, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Item.coal, 64));
		
		
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftTransport.pipeItemsDiamond, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftTransport.pipeItemsWood, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(BuildCraftEnergy.engineBlock, 64, 0));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.torchRedstoneActive, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Item.redstone, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.torchWood, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftTransport.pipeItemsIron, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftTransport.pipeItemsObsidian, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(net.minecraft.src.BuildCraftCore.wrenchItem, 1));

//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.glass, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(BuildCraftCore.goldGearItem, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(BuildCraftTransport.pipeItemsDiamond, 64));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(Block.torchRedstoneActive, 1));
//			entityplayer.inventory.addItemStackToInventory(new ItemStack(BuildCraftFactory.autoWorkbenchBlock, 64));
	}

}
