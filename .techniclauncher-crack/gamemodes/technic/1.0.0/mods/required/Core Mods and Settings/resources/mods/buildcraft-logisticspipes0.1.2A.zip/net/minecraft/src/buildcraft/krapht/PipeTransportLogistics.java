/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import java.util.Iterator;
import java.util.LinkedList;

import net.minecraft.src.TileEntity;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.api.EntityPassiveItem;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.api.Position;
import net.minecraft.src.buildcraft.core.Utils;
import net.minecraft.src.buildcraft.transport.PipeTransportItems;
import net.minecraft.src.buildcraft.transport.TileGenericPipe;
import net.minecraft.src.krapht.ItemIdentifier;

public class PipeTransportLogistics extends PipeTransportItems {

	private class ResolvedRoute{
		Router bestRouter;
		boolean isDefault;
	}
	
	private RoutedPipe _pipe = null;
	
	public PipeTransportLogistics() {
		allowBouncing = true;
	}

//	@Override
//	public void entityEntering(EntityPassiveItem item, Orientations orientation) {
//		// TODO Auto-generated method stub
//		super.entityEntering(item, orientation);
//		
//		RoutedPipe pipe = (RoutedPipe)container.pipe;
//		
//		if (item instanceof RoutedEntityItem){
//			if (((RoutedEntityItem)item).destinationRouter == pipe.router){
//				pipe.RoutedEntityArriving((RoutedEntityItem) item);
//			}
//		}
//	}
	
	
//	private Router setRouteFor(EntityData data){
//		//Get specific route
//		boolean isDefault = false;
//
//		Router bestRouter = LogisticsManager.getDestinationFor(ItemIdentifier.get(data.item.item), _pipe.router.getRouteTable().keySet());
//		if (bestRouter == null)
//		{
//			bestRouter = LogisticsManager.getDestinationFor(null, _pipe.router.getRouteTable().keySet());
//			isDefault = true;
//		}
//
//		if (bestRouter != null)	{
//			RoutedEntityItem newItem = new RoutedEntityItem(this.worldObj, data.item);
//			newItem.sourceRouter = _pipe.router;
//			_pipe.router.startTrackingRoutedItem(newItem);
//			newItem.destinationRouter = bestRouter;
//			newItem.isDefaultRouted = isDefault;
//			data.item = newItem;
//			data.item.speed = Math.max(data.item.speed, Utils.pipeNormalSpeed * (isDefault?mod_LogisticsPipes.LOGISTICS_DEFAULTROUTED_SPEED_MULTIPLIER : mod_LogisticsPipes.LOGISTICS_ROUTED_SPEED_MULTIPLIER));
//		}
//		return bestRouter;
//	}
	
	private ResolvedRoute resolveRoute(EntityData data){
		ResolvedRoute route = new ResolvedRoute();
		route.bestRouter = mod_LogisticsPipes.logisticsManager.getDestinationFor(ItemIdentifier.get(data.item.item), _pipe.router.getRouteTable().keySet());
		if (route.bestRouter == null){
			route.bestRouter = mod_LogisticsPipes.logisticsManager.getDestinationFor(null, _pipe.router.getRouteTable().keySet());
			route.isDefault = true;
		}
		return route;
	}
	
	//TODO: Refactor to reduce code duplication
	@Override
	public Orientations resolveDestination(EntityData data) {
		if (_pipe == null){
			_pipe = (RoutedPipe) container.pipe;
		}
		if (!(data.item instanceof RoutedEntityItem )){
			ResolvedRoute bestRoute = resolveRoute(data);
			
			if (bestRoute.bestRouter == null){
				//No idea where to send this. Drop it
				return Orientations.Unknown;
			}
			
			RoutedEntityItem newItem = new RoutedEntityItem(this.worldObj, data.item);
			newItem.setDefaultRouted(bestRoute.isDefault);
			newItem.sourceRouter = _pipe.router;
			newItem.destinationRouter = bestRoute.bestRouter;
			_pipe.router.startTrackingRoutedItem(newItem);
			bestRoute.bestRouter.startTrackingInboundItem(newItem);
			data.item = newItem;
			
			if (bestRoute.bestRouter != _pipe.router){
				return _pipe.router.getRouteTable().get(bestRoute.bestRouter);
			}
			
			//If the best destination is the current router, continue
		}
		RoutedEntityItem item = (RoutedEntityItem)data.item;
		//a routed item with destination stripped. Check if we can get new route		
		if (item.destinationRouter == null)	{
			ResolvedRoute bestRoute = resolveRoute(data);
			
			if (bestRoute.bestRouter == null){
				//Unable to find a new destination, drop it
				return Orientations.Unknown;
			}
			item.setDefaultRouted(bestRoute.isDefault);
			item.destinationRouter = bestRoute.bestRouter;
			item.destinationRouter.startTrackingInboundItem(item);
		}
		
		if (item.destinationRouter == _pipe.router){
			return destinationReached(item);
		}

		Orientations exit = _pipe.router.getRouteTable().get(item.destinationRouter); 
		if (exit != null) {
			item.refreshSpeed();
			if (item.sourceRouter != _pipe.router){
				_pipe.stat_lifetime_relayed++;
				_pipe.stat_session_relayed++;
			}
			return(exit);
		}
		
		//No route, attempt to reroute!
		ResolvedRoute bestRoute = resolveRoute(data);
		if (bestRoute.bestRouter == null){
			//Failed, drop package
			return Orientations.Unknown;
		}
		item.changeDestination(bestRoute.bestRouter);
		item.setDefaultRouted(bestRoute.isDefault);
		if (item.destinationRouter == _pipe.router){
			return destinationReached(item);
		}
		return _pipe.router.getRouteTable().get(item.destinationRouter);
	}

	
	
	private Orientations destinationReached(RoutedEntityItem item) {
		item.arrived = true;
		if (item.sourceRouter != null){
			item.sourceRouter.outboundItemArrived(item);
		}
		if  (item.destinationRouter != null){
			item.destinationRouter.inboundItemArrived(item);
		}
		
		_pipe.stat_lifetime_recieved++;
		_pipe.stat_session_recieved++;
		
		item.destinationRouter = null;
		
		//1) Deliver to attached chest/non-pipe
		LinkedList<Orientations> possible = getPossibleMovements(getPosition(), item);
		Iterator<Orientations> iterator = possible.iterator();
		while (iterator.hasNext())	{
			Position p = new Position(_pipe.xCoord, _pipe.yCoord, _pipe.zCoord, iterator.next());
			p.moveForwards(1);
			TileEntity tile = worldObj.getBlockTileEntity((int)p.x, (int)p.y, (int)p.z);
			if (tile instanceof TileGenericPipe){
				iterator.remove();
			}
		}
		if (possible.size() > 0){
			return possible.get(worldObj.rand.nextInt(possible.size()));
		}
		
		//2) deliver to attached pipe that does not have a route
		LinkedList<Orientations> nonRoutes = _pipe.router.GetNonRoutedExits();
		iterator = nonRoutes.iterator();
		while(iterator.hasNext()) {
			Position p = new Position(_pipe.xCoord, _pipe.yCoord, _pipe.zCoord, iterator.next());
			p.moveForwards(1);
			TileEntity tile = worldObj.getBlockTileEntity((int)p.x, (int)p.y, (int)p.z); 
			if (tile == null || !( tile instanceof TileGenericPipe) || !((TileGenericPipe)tile).acceptItems()){
				iterator.remove();
			}
		}

		if (nonRoutes.size() != 0){
			return nonRoutes.get(worldObj.rand.nextInt(nonRoutes.size()));
		}
		
		//3) Eject				
		return Orientations.Unknown;
	}
}
