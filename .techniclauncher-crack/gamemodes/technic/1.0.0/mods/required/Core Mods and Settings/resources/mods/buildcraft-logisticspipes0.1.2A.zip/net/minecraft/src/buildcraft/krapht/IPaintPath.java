package net.minecraft.src.buildcraft.krapht;

import net.minecraft.src.World;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.api.Position;

public interface IPaintPath {
	public void addLaser(World worldObj, Position start, Orientations o);
}
