/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht.logic;

import java.util.Iterator;
import java.util.LinkedList;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.krapht.IRequestItems;
import net.minecraft.src.buildcraft.krapht.IRequireReliableTransport;
import net.minecraft.src.buildcraft.krapht.LogisticsManager;
import net.minecraft.src.buildcraft.krapht.LogisticsRequest;
import net.minecraft.src.buildcraft.krapht.RoutedPipe;
import net.minecraft.src.buildcraft.transport.TileGenericPipe;
import net.minecraft.src.krapht.ItemIdentifier;

public class LogicRequest extends BaseRoutingLogic implements IRequireReliableTransport{

	private final LinkedList<ItemIdentifier> _lostItems = new LinkedList<ItemIdentifier>();
	
	@Override
	public boolean blockActivated(EntityPlayer entityplayer) {
		
		if (entityplayer.getCurrentEquippedItem() != null){
			
			if (entityplayer.getCurrentEquippedItem().getItem() == mod_LogisticsPipes.LogisticsNetworkMonitior){
				return super.blockActivated(entityplayer);
			}
			
			LogisticsRequest request = new LogisticsRequest(ItemIdentifier.get(entityplayer.getCurrentEquippedItem()), entityplayer.getCurrentEquippedItem().stackSize, (IRequestItems) ((RoutedPipe)((TileGenericPipe)this.container).pipe));
			LinkedList<String> errors = new LinkedList<String>();
			boolean result = LogisticsManager.Request(request, ((RoutedPipe)((TileGenericPipe)this.container).pipe).router.getRouteTable().keySet(), errors);
			if (!result){
				for (String error : errors){
					entityplayer.addChatMessage("Missing: " + error);
				}
			}
			else{
				entityplayer.addChatMessage("Request successfull!");
			}
			return true;
		}
		
		return super.blockActivated(entityplayer);
	}

	@Override
	public void destroy() {}

	@Override
	public void onWrenchClicked(EntityPlayer entityplayer) {}
	
	@Override
	public void updateEntity() {
		// TODO Auto-generated method stub
		super.updateEntity();
		
		if (!_lostItems.isEmpty()){
			Iterator<ItemIdentifier> iterator = _lostItems.iterator();
			while(iterator.hasNext()){
				LogisticsRequest request = new LogisticsRequest(iterator.next(), 1, (IRequestItems)this.getRoutedPipe());
				if (LogisticsManager.Request(request, ((RoutedPipe)((TileGenericPipe)this.container).pipe).router.getRouteTable().keySet(), null)){
					iterator.remove();
				}
				
			}
		}
	}

	
	/* IRequireReliableTransport */
	@Override
	public void itemLost(ItemIdentifier item) {
		_lostItems.add(item);
	}

	@Override
	public void itemArrived(ItemIdentifier item) {}
}
