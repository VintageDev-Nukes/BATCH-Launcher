///** 
// * Copyright (c) Krapht, 2011
// * 
// * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
// * License 1.0, or MMPL. Please check the contents of the license located in
// * http://www.mod-buildcraft.com/MMPL-1.0.txt
// */
//
//package net.minecraft.src.buildcraft.krapht;
//
//import net.minecraft.src.EntityPlayer;
//import net.minecraft.src.IInventory;
//import net.minecraft.src.InventoryPlayer;
//import net.minecraft.src.ItemStack;
//import net.minecraft.src.Slot;
//import net.minecraft.src.buildcraft.core.BuildCraftContainer;
//import net.minecraft.src.krapht.ItemIdentifier;
//
//public class SupplierPipeContainer extends BuildCraftContainer {
//	
//	public class DummySlot extends Slot{
//		public DummySlot(IInventory iinventory, int i, int j, int k) {
//			super(iinventory, i, j, k);
//			// TODO Auto-generated constructor stub
//		}
//	}
//	IInventory playerIInventory;
//	IInventory dummyIInventory;
//	
//	private void addInventory(int xOffset, int yOffset){
//		//Player "backpack"
//        for(int row = 0; row < 3; row++) {
//            for(int column = 0; column < 9; column++)
//            {
//                addSlot(new Slot(playerIInventory, column + row * 9 + 9, xOffset + column * 18, yOffset + row * 18));
//            }
//        }
//
//        //Player "hotbar"
//        for(int i1 = 0; i1 < 9; i1++) {
//            addSlot(new Slot(playerIInventory, i1, xOffset + i1 * 18, yOffset + 58));
//        }
//	}
//	
//	public SupplierPipeContainer (IInventory playerInventory, IInventory dummyInventory) {
//		super(dummyInventory.getSizeInventory());
//		this.playerIInventory = playerInventory;
//		this.dummyIInventory = dummyInventory;
//		
//		addSlot(new DummySlot(dummyInventory, 0, 0, 0));
//		
//		addInventory(18,97);
//	}
//	
//	@Override
//	public void updateCraftingResults() {}
//	
//	@Override
//	public ItemStack transferStackInSlot(int i)
//    {
//		return null;
////        Slot slot = (Slot)inventorySlots.get(i);
////        if(slot != null && slot instanceof DummySlot)
////        {
////            return null;
////        } 
////        
////        return super.transferStackInSlot(i);
//    }
//	
//	@Override
//	public ItemStack slotClick(int slotId, int j, boolean flag, EntityPlayer entityplayer) {
//		// TODO Auto-generated method stub
//		if (slotId < 0) return super.slotClick(slotId, j, flag, entityplayer);
//		Slot slot = (Slot)inventorySlots.get(slotId);
//		if (slot == null || !(slot instanceof DummySlot)) return super.slotClick(slotId, j, flag, entityplayer);
//		
//		InventoryPlayer inventoryplayer = entityplayer.inventory;
//		ItemStack currentlyEquippedStack = inventoryplayer.getItemStack();
//		if (currentlyEquippedStack == null){
//			slot.putStack(null);
//			return currentlyEquippedStack;
//		}
//		
//		if (!slot.getHasStack()){
//			slot.putStack(currentlyEquippedStack.copy());
//			return currentlyEquippedStack;
//		}
//		
//		ItemIdentifier currentItem = ItemIdentifier.get(currentlyEquippedStack);
//		ItemIdentifier slotItem = ItemIdentifier.get(slot.getStack());
//		if (currentItem == slotItem){
//			if (j == 1){
//				slot.decrStackSize(1);
//			} else {
//				slot.decrStackSize(-1);
//			}
//			
//				
//		}
//		return currentlyEquippedStack;
//
//		//return super.slotClick(slotId, j, flag, entityplayer);
//		
//	}
//	
//	
//	
//}
