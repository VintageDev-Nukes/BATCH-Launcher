package net.minecraft.src.krapht;

import net.minecraft.src.IInventory;

public class InventoryUtilFactory {
	public InventoryUtil getInventoryUtil(IInventory inv)
	{
		return new InventoryUtil(inv);
	}

}
