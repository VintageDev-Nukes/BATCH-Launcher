package net.minecraft.src.buildcraft.krapht;

import net.minecraft.src.krapht.ItemIdentifier;

public interface IRequireReliableTransport {
	public void itemLost(ItemIdentifier item);
	public void itemArrived(ItemIdentifier item);

}
