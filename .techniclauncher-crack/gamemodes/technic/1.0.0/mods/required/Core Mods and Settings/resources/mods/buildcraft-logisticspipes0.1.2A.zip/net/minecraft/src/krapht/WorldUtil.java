package net.minecraft.src.krapht;

import java.util.LinkedList;

import net.minecraft.src.IInventory;
import net.minecraft.src.TileEntity;
import net.minecraft.src.World;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.api.Position;

public class WorldUtil {
	public class AdjacentTile {
		public TileEntity tile;
		public Orientations orientation;
	
		AdjacentTile(TileEntity tile, Orientations orientation){
			this.tile = tile;
			this.orientation = orientation;
		}
	}
	
	private int _x;
	private int _y;
	private int _z;
	
	private World _worldObj;
	
	public WorldUtil(World worldObj, int x, int y, int z) {
		this._worldObj = worldObj;
		this._x = x;
		this._y = y;
		this._z = z;
	}

	public LinkedList<AdjacentTile> getAdjacentTileEntities() {
		// TODO Auto-generated method stub
		LinkedList<AdjacentTile> foundTiles = new LinkedList<AdjacentTile>();
		for (Orientations o : Orientations.values()){
			Position p = new Position(_x, _y, _z, o);
			p.moveForwards(1);
			TileEntity tile = _worldObj.getBlockTileEntity((int)p.x, (int)p.y, (int)p.z);
			
			if (tile == null) continue;
			foundTiles.add(new AdjacentTile(tile, o));
		}
		return foundTiles;
	}
}
