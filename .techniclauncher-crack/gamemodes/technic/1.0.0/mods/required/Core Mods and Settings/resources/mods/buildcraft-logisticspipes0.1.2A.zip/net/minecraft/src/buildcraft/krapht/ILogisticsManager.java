package net.minecraft.src.buildcraft.krapht;

import java.util.Set;

import net.minecraft.src.krapht.ItemIdentifier;

public interface ILogisticsManager {
	public Router getDestinationFor(ItemIdentifier item, Set<Router> validDestinations);
}