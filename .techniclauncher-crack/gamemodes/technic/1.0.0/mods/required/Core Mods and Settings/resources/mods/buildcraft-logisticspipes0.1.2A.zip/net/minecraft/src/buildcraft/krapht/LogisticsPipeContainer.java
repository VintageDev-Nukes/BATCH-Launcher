/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import net.minecraft.src.IInventory;
import net.minecraft.src.Slot;
import net.minecraft.src.buildcraft.core.BuildCraftContainer;

/*
 * Most of the code in this class is taken from Buildcraft
 * /minecraft/src/buildcraft/transport/CraftingDiamondPipe.java 
 * with only minor modifications so all credit goes to SpaceToad
 */
public class LogisticsPipeContainer extends BuildCraftContainer {
	IInventory playerIInventory;
	IInventory logisticsInventory;
	
	public LogisticsPipeContainer (IInventory playerInventory, IInventory logisticsInventory) {
		super(logisticsInventory.getSizeInventory());
		this.playerIInventory = playerInventory;
		this.logisticsInventory = logisticsInventory;
		
		//Pipe slots
       for(int pipeSlot = 0; pipeSlot < 9; pipeSlot++){
    	   addSlot(new Slot(logisticsInventory, pipeSlot, 8 + pipeSlot * 18, 18));
       }

		//Player "backpack"
        for(int l = 0; l < 3; l++) {
            for(int k1 = 0; k1 < 9; k1++)
            {
                addSlot(new Slot(playerInventory, k1 + l * 9 + 9, 8 + k1 * 18, 60 + l * 18));
            }
        }

        //Player "hotbar"
        for(int i1 = 0; i1 < 9; i1++) {
            addSlot(new Slot(playerInventory, i1, 8 + i1 * 18, 118));
        }
	}
}
