/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import java.beans.DesignMode;

import net.minecraft.src.ItemStack;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.api.EntityPassiveItem;
import net.minecraft.src.buildcraft.api.Orientations;
import net.minecraft.src.buildcraft.api.Position;
import net.minecraft.src.buildcraft.core.Utils;
import net.minecraft.src.buildcraft.krapht.logic.BaseRoutingLogic;
import net.minecraft.src.buildcraft.transport.Pipe;
import net.minecraft.src.buildcraft.transport.PipeTransportItems;

public abstract class RoutedPipe extends Pipe {

	public Router router;
	private static int pipecount = 0;
	private int _delayOffset = 0;
	private int _nextTexture = getCenterTexture();
	
	private boolean _initialInit = true;
	
	public int stat_session_sent;
	public int stat_session_recieved;
	public int stat_session_relayed;
	
	public long stat_lifetime_sent;
	public long stat_lifetime_recieved;
	public long stat_lifetime_relayed;
	
	public RoutedPipe(BaseRoutingLogic logic, int itemID) {
		super(new PipeTransportLogistics(), logic, itemID);
		((PipeTransportItems) transport).allowBouncing = true;
		router = new Router(this);
		
		pipecount++;
		//Roughly spread pipe updates throughout the frequency, no need to maintain balance
		_delayOffset = pipecount % mod_LogisticsPipes.LOGISTICS_DETECTION_FREQUENCY; 

	}
	
	public void sendRoutedItem(ItemStack item, Router destination, Position origin){
		Position entityPos = new Position(origin.x + 0.5, origin.y + Utils.getPipeFloorOf(item), origin.z + 0.5, origin.orientation.reverse());
		entityPos.moveForwards(0.5);
		
		RoutedEntityItem routedItem = new RoutedEntityItem(worldObj, new EntityPassiveItem(worldObj, entityPos.x, entityPos.y, entityPos.z, item));
		routedItem.sourceRouter = this.router;
		router.startTrackingRoutedItem(routedItem);
		routedItem.destinationRouter = destination;
		if (destination != null){
			destination.startTrackingInboundItem(routedItem);
		}
		
		routedItem.speed = Utils.pipeNormalSpeed * mod_LogisticsPipes.LOGISTICS_ROUTED_SPEED_MULTIPLIER;
		((PipeTransportItems) transport).entityEntering(routedItem, entityPos.orientation);
		stat_lifetime_sent++;
		stat_session_sent++;
			
	}
	
	@Override
	public void updateEntity() {
		super.updateEntity();
		router.update(worldObj.getWorldTime() % mod_LogisticsPipes.LOGISTICS_DETECTION_FREQUENCY == _delayOffset || _initialInit);
		_initialInit = false;
	}	
	
	@Override
	public void destroy() {
		super.destroy();
		router.destroy();
		if (logic instanceof BaseRoutingLogic){
			((BaseRoutingLogic)logic).destroy();
		}
		//Just in case
		pipecount = Math.max(pipecount - 1, 0);
	}
	
	@Override
	public final int getBlockTexture(){
		return _nextTexture;
	}
	
	public abstract int getCenterTexture();
	
	@Override
	public final void prepareTextureFor(Orientations connection) {

		if (connection == Orientations.Unknown || this.router == null){
			_nextTexture =  getCenterTexture();
			return;
		}
		
		if (this.router.isRoutedExit(connection)) {
			_nextTexture = mod_LogisticsPipes.LOGISTICSPIPE_ROUTED_TEXTURE;
		}
		else {
			_nextTexture = mod_LogisticsPipes.LOGISTICSPIPE_NOTROUTED_TEXTURE;
		}
	}
	
	@Override
	public void writeToNBT(NBTTagCompound nbttagcompound) {
		// TODO Auto-generated method stub
		super.writeToNBT(nbttagcompound);
		nbttagcompound.setLong("stat_lifetime_sent", stat_lifetime_sent);
		nbttagcompound.setLong("stat_lifetime_recieved", stat_lifetime_recieved);
		nbttagcompound.setLong("stat_lifetime_relayed", stat_lifetime_relayed);
	}
	
	@Override
	public void readFromNBT(NBTTagCompound nbttagcompound) {
		// TODO Auto-generated method stub
		super.readFromNBT(nbttagcompound);
		stat_lifetime_sent = nbttagcompound.getLong("stat_lifetime_sent");
		stat_lifetime_recieved = nbttagcompound.getLong("stat_lifetime_recieved");
		stat_lifetime_relayed = nbttagcompound.getLong("stat_lifetime_relayed");
	}
	
	
//	public void RoutedEntityArriving(RoutedEntityItem item){
//		
//	}
}
