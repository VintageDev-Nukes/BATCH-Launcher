/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import net.minecraft.src.IInventory;
import net.minecraft.src.Slot;
import net.minecraft.src.buildcraft.core.BuildCraftContainer;

public class LogisticsCraftingContainer2 extends BuildCraftContainer {
	IInventory playerIInventory;
	IInventory logisticsInventory;
	
	public LogisticsCraftingContainer2 (IInventory playerInventory, IInventory logisticsInventory) {
		super(logisticsInventory.getSizeInventory());
		this.playerIInventory = playerInventory;
		this.logisticsInventory = logisticsInventory;
		
		//Input slots
        for(int l = 0; l < 9; l++) {
        	addSlot(new Slot(logisticsInventory, l, 18 + l * 18, 18));
        }
        
        //Output slot
        addSlot(new Slot(logisticsInventory, 9, 90, 64));


		//Player "backpack"
        for(int l = 0; l < 3; l++) {
            for(int k1 = 0; k1 < 9; k1++) {
                addSlot(new Slot(playerInventory, k1 + l * 9 + 9, 18 + k1 * 18, 97 + l * 18));
            }
        }

        //Player "hotbar"
        for(int i1 = 0; i1 < 9; i1++) {
            addSlot(new Slot(playerInventory, i1, 18 + i1 * 18, 155));
        }
	}
	
//	@Override
//	public void putStackInSlot(int i, ItemStack itemstack) {
//		// TODO Auto-generated method stub
//		if (i > 9){
//			super.putStackInSlot(i, itemstack);
//			return;
//		}
//		
//		ItemStack items = new ItemStack(itemstack.itemID, itemstack.stackSize, itemstack.getItemDamage());
//
//		super.putStackInSlot(i, items);
//	}
//	
//	@Override
//	public ItemStack slotClick(int i, int j, boolean flag,
//			EntityPlayer entityplayer) {
//		// TODO Auto-generated method stub
//		return super.slotClick(i, j, flag, entityplayer);
//	}
}