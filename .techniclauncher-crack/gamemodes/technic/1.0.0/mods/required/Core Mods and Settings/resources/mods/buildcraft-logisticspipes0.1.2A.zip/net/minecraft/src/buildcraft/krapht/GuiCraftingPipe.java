///** 
// * Copyright (c) Krapht, 2011
// * 
// * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
// * License 1.0, or MMPL. Please check the contents of the license located in
// * http://www.mod-buildcraft.com/MMPL-1.0.txt
// */
//
//package net.minecraft.src.buildcraft.krapht;
//
//import net.minecraft.src.GuiContainer;
//import net.minecraft.src.IInventory;
//import net.minecraft.src.InventoryPlayer;
//import net.minecraft.src.buildcraft.krapht.logic.LogicCrafting;
//
//import org.lwjgl.opengl.GL11;
//
///*
// * Most of the code in this class is taken from Buildcraft
// * /minecraft/src/buildcraft/factory/ContainerAutoWorkbench.java 
// * with only minor modifications so all credit goes to SpaceToad
// */
//public class GuiCraftingPipe extends GuiContainer {
//
//	public GuiCraftingPipe(InventoryPlayer inventoryplayer, IInventory pipeInventory, LogicCrafting logic) {
//		super(new LogisticsCraftingContainer(inventoryplayer, pipeInventory));
//	}
//
//	public void onGuiClosed() {
//		super.onGuiClosed();
//		inventorySlots.onCraftGuiClosed(mc.thePlayer);
//	}
//
//	protected void drawGuiContainerForegroundLayer() {
//		fontRenderer.drawString("Input", 28, 6, 0x404040);
//		fontRenderer.drawString("Expected output", 89, 19, 0x404040);
//		fontRenderer.drawString("Inventory", 8, (ySize - 96) + 2, 0x404040);
//		
//	}
//
//	@Override
//	protected void drawGuiContainerBackgroundLayer(float f, int x, int y) {
//		int i = mc.renderEngine.getTexture("/gui/crafting.png");
//		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
//		mc.renderEngine.bindTexture(i);
//		int j = (width - xSize) / 2;
//		int k = (height - ySize) / 2;
//		drawTexturedModalRect(j, k, 0, 0, xSize, ySize);
//	}
//
//}
