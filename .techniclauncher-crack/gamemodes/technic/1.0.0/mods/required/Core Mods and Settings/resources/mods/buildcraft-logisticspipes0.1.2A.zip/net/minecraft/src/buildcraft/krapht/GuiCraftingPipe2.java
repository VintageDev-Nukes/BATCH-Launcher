/** 
 * Copyright (c) Krapht, 2011
 * 
 * "LogisticsPipes" is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src.buildcraft.krapht;

import net.minecraft.src.GuiButton;
import net.minecraft.src.GuiContainer;
import net.minecraft.src.IInventory;
import net.minecraft.src.InventoryPlayer;
import net.minecraft.src.mod_LogisticsPipes;
import net.minecraft.src.buildcraft.krapht.logic.LogicCrafting;
import net.minecraft.src.forge.MinecraftForgeClient;

import org.lwjgl.opengl.GL11;

/*
 * Most of the code in this class is taken from Buildcraft
 * /minecraft/src/buildcraft/factory/ContainerAutoWorkbench.java 
 * with only minor modifications so all credit goes to SpaceToad
 */
public class GuiCraftingPipe2 extends GuiContainer {

	private final int plus10 = 0;
	private final int plus1 = 1;
	private final int minus1 = 2;
	private final int minus10 = 3;
	private final LogicCrafting _logic;
	
	public GuiCraftingPipe2(InventoryPlayer inventoryplayer, IInventory pipeInventory, LogicCrafting logic) {
		super(new LogisticsCraftingContainer2(inventoryplayer, pipeInventory));
		_logic = logic;
		xSize = 195;
		ySize = 187;
	}

	@Override
	public void initGui() {
		super.initGui();
		
		controlList.add(new SmallGuiButton(0, (width-xSize) / 2 + 164, (height - ySize) / 2 + 50, 10,10, ">"));
		controlList.add(new SmallGuiButton(1, (width-xSize) / 2 + 129, (height - ySize) / 2 + 50, 10,10, "<"));
		controlList.add(new SmallGuiButton(2, (width-xSize) / 2 + 138, (height - ySize) / 2 + 75, 30,10, "Paint"));

//        //+10 buttons
//        for (int i = 0; i < 10; i++)
//        {
//        	controlList.add(new SmallGuiButton(plus10 + i, width / 4 - 6 + i * 18 + ((i / 9)*24), height / 4 - 27, 15, 10, "++"));
//        }
//        
//        //+1
//        for (int i = 0; i < 10; i++)
//        {
//        	controlList.add(new SmallGuiButton(plus1 + i, width / 4 - 4 + i * 18 + ((i / 9)*24), height / 4 - 16, 10, 10, "+"));
//        }
//        
//        
//        //-1
//        for (int i = 0; i < 10; i++)
//        {
//        	controlList.add(new SmallGuiButton(minus1 + i, width / 4 - 4 + i * 18 + ((i / 9)*24), height / 4 + 14, 10, 10, "-"));
//        }
//        
//        //-10
//        for (int i = 0; i < 10; i++)
//        {
//        	controlList.add(new SmallGuiButton(minus10 + i, width / 4 - 6 + i * 18 + ((i / 9)*24), height / 4 + 25, 15, 10, "--"));
//        }

	}
	
	
	@Override
	protected void actionPerformed(GuiButton guibutton) {
		switch(guibutton.id){
		case 0:
			_logic.setNextSatellite();
			return;
		case 1: 
			_logic.setPrevSatellite();
			return;
		case 2:
			_logic.paintPathToSatellite();
		default:
			super.actionPerformed(guibutton);
			return;
		}
	}
	
	@Override
	public void onGuiClosed() {
		super.onGuiClosed();
		inventorySlots.onCraftGuiClosed(mc.thePlayer);
	}

	@Override
	protected void drawGuiContainerForegroundLayer() {
		fontRenderer.drawString("Inputs", 18, 7, 0x404040);
		fontRenderer.drawString("Output", 48, 67, 0x404040);
		fontRenderer.drawString("Inventory", 18, 86, 0x404040);
		fontRenderer.drawString("Satellite", 132, 7, 0x404040);
		
		
		if (_logic.SatelliteId == 0){
			fontRenderer.drawString("Off", 144, 52, 0x404040);
			return;
		}
		if (_logic.isSatelliteConnected()){
			MinecraftForgeClient.bindTexture(mod_LogisticsPipes.LOGISTICSPIPE_ROUTED_TEXTURE_FILE);
		}else{
			MinecraftForgeClient.bindTexture(mod_LogisticsPipes.LOGISTICSPIPE_NOTROUTED_TEXTURE_FILE);
		}

		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		drawTexturedModalRect(155, 50, 10 * (xSize / 16) , 0, 10, 10);
		MinecraftForgeClient.unbindTexture();
		fontRenderer.drawString(""+_logic.SatelliteId , 155 - fontRenderer.getStringWidth(""+_logic.SatelliteId) , 52, 0x404040);

		
	}

	@Override
	protected void drawGuiContainerBackgroundLayer(float f, int x, int y) {
		int i = mc.renderEngine.getTexture("/net/minecraft/src/buildcraft/krapht/gui/crafting.png");
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		mc.renderEngine.bindTexture(i);
		int j = (width - xSize) / 2;
		int k = (height - ySize) / 2;
		//
		//mc.renderEngine.bindTexture(mod_LogisticsPipes.)
		//mc.renderEngine.bindTexture(BuildCraftCore.redLaserTexture);
		drawTexturedModalRect(j, k, 0, 0, xSize, ySize);
		
		
		//drawRect(400, 400, 0, 0, 0x404040);
		
	}

}
